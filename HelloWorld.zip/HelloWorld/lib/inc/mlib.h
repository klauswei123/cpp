//
// Created by qlist on 2019/2/10.
//

#ifndef HELLOWORLD_MLIB_H
#define HELLOWORLD_MLIB_H

void mlib_fun();

#endif //HELLOWORLD_MLIB_H
