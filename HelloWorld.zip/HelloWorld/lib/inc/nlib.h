//
// Created by qlist on 2019/2/10.
//

#ifndef HELLOWORLD_NLIB_H
#define HELLOWORLD_NLIB_H

void nlib_fun();

#endif //HELLOWORLD_NLIB_H
