//
// Created by qlist on 2019/2/9.
//

#ifndef HELLOWORLD_ALIB_H
#define HELLOWORLD_ALIB_H

void alib_fun();

#endif //HELLOWORLD_ALIB_H
