//
// Created by qlist on 2019/2/9.
//

#include <cstdio>

void alib_fun()
{
    fprintf(stderr, "call alib_fun.\n");
}