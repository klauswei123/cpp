//
// Created by qlist on 2019/2/9.
//

#ifndef HELLOWORLD_BLIB_H
#define HELLOWORLD_BLIB_H

void blib_fun();

#endif //HELLOWORLD_BLIB_H
