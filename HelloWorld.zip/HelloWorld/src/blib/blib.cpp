//
// Created by qlist on 2019/2/9.
//

#include <cstdio>

void blib_fun()
{
    fprintf(stderr, "call blib_fun.\n");
}